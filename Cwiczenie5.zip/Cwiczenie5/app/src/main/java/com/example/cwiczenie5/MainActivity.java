package com.example.cwiczenie5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    static final String TAG= "Log Test: ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuu,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.menu1:
                showAlert();
                return true;
            case R.id.menu2:
                showToast();
                return true;
            case R.id.menu3:
                showLog();
                return true;
            case R.id.menu4:
                nextActivity();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void nextActivity() {
        Intent intent = new Intent(this, NewtonRaphson.class);
        startActivity(intent);
    }

    private void showLog() {
        double a = 10;
    Log.i(TAG,"Wynik: " + String.valueOf(a));
    }

    private void showToast() {
        Toast toast = Toast.makeText(getApplicationContext(),R.string.menu2,Toast.LENGTH_SHORT);
        toast.show();

    }

    private void showAlert() {
        AlertDialog builder= new AlertDialog.Builder(this).setMessage("Autor : Kacper Cichorski").setTitle("O autorze").create();
        builder.show();
    }

}